export type UserMenuDropdownItem = {
  iconPath: string;
  label: string;
  onClick: () => void;
};
