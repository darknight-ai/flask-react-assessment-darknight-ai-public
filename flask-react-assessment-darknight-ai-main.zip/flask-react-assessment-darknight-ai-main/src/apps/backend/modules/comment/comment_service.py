from modules.application.repository import db
from modules.comment.comment_model import Comment

class CommentService:
    """Service layer for handling comment-related database operations."""

    @staticmethod
    def get_comments_by_task(task_id: int):
        """Fetch all comments related to a specific task."""
        return Comment.query.filter_by(task_id=task_id).all()

    @staticmethod
    def add_comment(task_id: int, content: str):
        """Add a new comment to a task."""
        comment = Comment(task_id=task_id, content=content)
        db.session.add(comment)
        db.session.commit()
        return comment

    @staticmethod
    def update_comment(comment_id: int, content: str):
        """Update an existing comment by its ID."""
        comment = Comment.query.get(comment_id)
        if not comment:
            return None
        comment.content = content
        db.session.commit()
        return comment

    @staticmethod
    def delete_comment(comment_id: int):
        """Delete a comment by its ID."""
        comment = Comment.query.get(comment_id)
        if not comment:
            return False
        db.session.delete(comment)
        db.session.commit()
        return True
