# modules/comment/comment_api.py
from flask import Blueprint, jsonify, request
from modules.comment.comment_model import Comment
from modules.application.repository import db

comment_blueprint = Blueprint("comment_blueprint", __name__)

# ✅ Get all comments
@comment_blueprint.route("/", methods=["GET"])
def get_all_comments():
    comments = Comment.query.all()
    return jsonify([c.to_dict() for c in comments]), 200


# ✅ Create a new comment
@comment_blueprint.route("/", methods=["POST"])
def create_comment():
    data = request.get_json()
    if not data or "username" not in data or "text" not in data:
        return jsonify({"error": "username and text are required"}), 400

    new_comment = Comment(username=data["username"], text=data["text"])
    db.session.add(new_comment)
    db.session.commit()

    return jsonify({"message": "Comment added", "comment": new_comment.to_dict()}), 201


# ✅ Get a comment by ID
@comment_blueprint.route("/<int:comment_id>", methods=["GET"])
def get_comment(comment_id):
    comment = Comment.query.get(comment_id)
    if not comment:
        return jsonify({"error": "Comment not found"}), 404
    return jsonify(comment.to_dict()), 200


# ✅ Update a comment
@comment_blueprint.route("/<int:comment_id>", methods=["PUT"])
def update_comment(comment_id):
    comment = Comment.query.get(comment_id)
    if not comment:
        return jsonify({"error": "Comment not found"}), 404

    data = request.get_json()
    if not data or "text" not in data:
        return jsonify({"error": "text is required"}), 400

    comment.text = data["text"]
    db.session.commit()
    return jsonify({"message": "Comment updated", "comment": comment.to_dict()}), 200


# ✅ Delete a comment
@comment_blueprint.route("/<int:comment_id>", methods=["DELETE"])
def delete_comment(comment_id):
    comment = Comment.query.get(comment_id)
    if not comment:
        return jsonify({"error": "Comment not found"}), 404

    db.session.delete(comment)
    db.session.commit()
    return jsonify({"message": "Comment deleted"}), 200
