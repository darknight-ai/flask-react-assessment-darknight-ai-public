# server.py
from flask import Flask
from flask_cors import CORS
from modules.application.repository import db

def create_app():
    app = Flask(__name__)
    CORS(app)

    # ✅ Database configuration
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydb.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # ✅ Initialize database
    db.init_app(app)

    # ✅ Import and register blueprints
    from modules.comment.comment_api import comment_blueprint
    app.register_blueprint(comment_blueprint, url_prefix="/comments")

    # ✅ Default route
    @app.route('/')
    def home():
        return {"message": "Server is running ✅"}

    # ✅ Create database tables
    with app.app_context():
        db.create_all()

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
