# routes/comment_routes.py
from flask import Blueprint, request, jsonify
from modules.comment.comment_model import Comment


comment_bp = Blueprint('comment_bp', __name__)

# In-memory "database" for now (you can replace with a real DB later)
comments = []

# CREATE a comment
@comment_bp.route('/comments', methods=['POST'])
def add_comment():
    data = request.get_json()
    new_comment = Comment(
        task_id=data.get('task_id'),
        author=data.get('author'),
        text=data.get('text')
    )
    comments.append(new_comment.to_dict())
    return jsonify({"message": "Comment added successfully!", "comment": new_comment.to_dict()}), 201


# READ all comments for a given task
@comment_bp.route('/comments/<int:task_id>', methods=['GET'])
def get_comments(task_id):
    task_comments = [c for c in comments if c['task_id'] == task_id]
    return jsonify(task_comments), 200


# UPDATE a comment
@comment_bp.route('/comments/<int:comment_id>', methods=['PUT'])
def update_comment(comment_id):
    data = request.get_json()
    for c in comments:
        if c['id'] == comment_id:
            c['text'] = data.get('text', c['text'])
            c['author'] = data.get('author', c['author'])
            return jsonify({"message": "Comment updated successfully!", "comment": c}), 200
    return jsonify({"message": "Comment not found!"}), 404


# DELETE a comment
@comment_bp.route('/comments/<int:comment_id>', methods=['DELETE'])
def delete_comment(comment_id):
    global comments
    comments = [c for c in comments if c['id'] != comment_id]
    return jsonify({"message": "Comment deleted successfully!"}), 200
