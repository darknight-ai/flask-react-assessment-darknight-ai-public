from datetime import datetime


def run() -> None:
    current_datetime = datetime.now()
    print("Current date and time:", current_datetime)


run()
