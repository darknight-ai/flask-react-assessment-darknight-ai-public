module.exports = {
  '*?(x)': () => 'npm run fmt',
};
